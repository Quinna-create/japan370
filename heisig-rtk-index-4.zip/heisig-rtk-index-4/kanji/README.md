## `KANJI_INDEX.csv` ##

This file comes from [this project][base-index] with the following
modifications made:

 * Kanji 96 and 221 have had their keywords swapped (96 is "town", and 221 is
   "village").
 * Kanji 230's position is swapped with 231.
 * Kanji 229 and 231 have had their keywords swapped (229 is "not yet", and 231
   is "extremity").

[base-index]: https://github.com/sdcr/heisig-kanjis
